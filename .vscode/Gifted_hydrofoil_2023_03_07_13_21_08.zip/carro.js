//código do carro

let xCarros = [600, 600, 600,600,600,600];
let yCarros = [40, 96, 150,210,260,320];
let velCarros = [3, 5, 3.2,4,5,3];
let comprimentoCarro=50;
let alturaCarros=40;



function mostraCarro(){
  for (let i = 0; i < imagemCarros.length; i = i + 1){
    image(imagemCarros[i], xCarros[i], yCarros[i], 50, 40);
  }
}

function movimentaCarro(){
  for (let i = 0; i < imagemCarros.length; i = i + 1){
    xCarros[i] -= velCarros[i];
  }
}

function voltaCarro(){
  for (let i = 0; i < imagemCarros.length; i = i + 1){
    if (passouTela(xCarros[i])){
      xCarros[i] = 600;
    }
  }
}

function passouTela(xCarro){
  return xCarro < - 50;
}





